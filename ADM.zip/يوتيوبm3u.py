import re
import json
import requests

# ==============================================================================
# 1. الثوابت والمتغيرات الأساسية لمحاكاة عميل ويب قادر على طلب HLS
# ==============================================================================

# سنستخدم هوية متصفح Safari على Mac، لأنه معروف بأنه يفضل HLS
# هذا يزيد من فرصة يوتيوب لإرسال hlsManifestUrl
WEB_SAFARI_CONTEXT = {
    "client": {
        "hl": "en",
        "gl": "US",
        "clientName": "WEB",
        "clientVersion": "2.20240725.01.00",
        "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    },
    "user": {},
    "request": {}
}

class ExtractorError(Exception):
    pass

def extract_video_id(url):
    patterns = [r'(?:v=|\/|embed\/|shorts\/|v%3D|be\/)([a-zA-Z0-9_-]{11})']
    for p in patterns:
        if match := re.search(p, url):
            return match.group(1)
    raise ExtractorError("لم يتم العثور على معرف فيديو صالح.")

# ==============================================================================
# 2. الدالة الرئيسية (مع خطوة بناء HLS Manifest)
# ==============================================================================
def get_hls_manifest_url(url):
    session = requests.Session()
    session.headers.update({
        "User-Agent": WEB_SAFARI_CONTEXT["client"]["userAgent"],
        "Accept-Language": "en-US,en;q=0.5"
    })

    try: 
        video_id = extract_video_id(url)
        print(f"🎬 الهدف: فيديو بمعرف {video_id} (باستخدام هوية Safari لطلب HLS)")
    except ExtractorError as e: 
        print(e); return

    print("\n--- [المرحلة 1: استخراج الإعدادات الديناميكية من صفحة /watch] ---")
    try:
        watch_url = f"https://www.youtube.com/watch?v={video_id}&hl=en"
        print(f"  - تحميل HTML من: {watch_url}")
        watch_html = session.get(watch_url).text
        
        ytcfg_match = re.search(r'ytcfg\.set\s*\(\s*({.+?})\s*\)\s*;', watch_html)
        if not ytcfg_match: raise ExtractorError("لم يتم العثور على 'ytcfg'.")
        
        ytcfg_data = json.loads(ytcfg_match.group(1))
        
        dynamic_api_key = ytcfg_data.get("INNERTUBE_API_KEY")
        if not dynamic_api_key: raise ExtractorError("لم يتم العثور على 'INNERTUBE_API_KEY'.")
            
        visitor_data = ytcfg_data.get("VISITOR_DATA")
        if not visitor_data: raise ExtractorError("لم يتم العثور على 'VISITOR_DATA'.")
            
        print("  - ✅ تم استخراج مفتاح API وبصمة الزائر بنجاح.")
        
    except Exception as e:
        print(f"  - ❌ فشل في الحصول على الإعدادات: {e}"); return

    print("\n--- [المرحلة 2: استدعاء API المشغل `v1/player`] ---")
    api_url = f"https://www.youtube.com/youtubei/v1/player?key={dynamic_api_key}"
    
    final_context = WEB_SAFARI_CONTEXT.copy()
    final_context["client"]["visitorData"] = visitor_data
    
    payload = {"context": final_context, "videoId": video_id}
    
    try: 
        print("  - إرسال طلب POST...")
        response = session.post(api_url, json=payload)
        response.raise_for_status()
        api_response_json = response.json()
        print("  - ✅ تم استلام استجابة JSON بنجاح.")
        # اختياري: طباعة الـ JSON لفحصه
        # print(json.dumps(api_response_json, indent=2))
    except Exception as e:
        print(f"  - ❌ فشل طلب الـ API: {e}"); return

    print("\n--- [المرحلة 3: البحث عن hlsManifestUrl] ---")
    streaming_data = api_response_json.get("streamingData")
    if not streaming_data:
        print("  - ❌ لم يتم العثور على قسم 'streamingData'.")
        return

    hls_manifest_api_url = streaming_data.get("hlsManifestUrl")
    if not hls_manifest_api_url:
        print("  - ❌ الخادم لم يرسل 'hlsManifestUrl' لهذا العميل. قد يكون الفيديو لا يدعم HLS أو يتطلب عميلاً آخر.")
        return
        
    print(f"  - ✅ تم العثور على رابط API بناء الـ Manifest:\n    {hls_manifest_api_url}")

    print("\n--- [المرحلة 4: طلب وبناء ملف m3u8 النهائي] ---")
    try:
        print(f"  - إرسال طلب GET إلى رابط الـ API...")
        # ملاحظة: لا نمرر أي كوكيز خاصة بالجلسة لهذا الطلب تحديدًا، كما تفعل yt-dlp
        manifest_response = requests.get(hls_manifest_api_url, headers={"User-Agent": WEB_SAFARI_CONTEXT["client"]["userAgent"]})
        manifest_response.raise_for_status()
        m3u8_content = manifest_response.text
        
        print("  - ✅ تم استلام محتوى ملف m3u8 بنجاح!")
        print("\n" + "="*24 + " 📜 محتوى ملف M3U8 النهائي 📜 " + "="*24)
        print(m3u8_content)

        # استخراج الروابط من داخل ملف M3U8 كمثال
        print("\n--- [المرحلة 5: استخراج الروابط من داخل M3U8] ---")
        media_urls = re.findall(r'^(https?://.*)$', m3u8_content, re.MULTILINE)
        if media_urls:
            print(f"  - ✅ تم العثور على {len(media_urls)} رابط وسائط داخل الملف:")
            for i, media_url in enumerate(media_urls):
                print(f"    رابط {i+1}: {media_url[:100]}...")
        else:
            print("  - ⚠️ لم يتم العثور على روابط وسائط مباشرة داخل الملف.")

    except Exception as e:
        print(f"  - ❌ فشل في الحصول على محتوى M3U8: {e}")


if __name__ == "__main__":
    url_input = input("ضع رابط يوتيوب: ").strip()
    if url_input:
        get_hls_manifest_url(url_input)
    else:
        print("لم يتم إدخال رابط.")
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
نسخة محسنة: جلب نتائج بحث m.youtube.com مع معالجة continuation
تحسين استخراج العناوين + محاولات oEmbed لاستخراج العناوين المفقودة
"""
import requests, json, re, time
from typing import Any, Dict, List, Optional

# ========== إعدادات ==========
search_query = "mrbeast"
url = f"https://m.youtube.com/results?sp=mAEA&search_query={search_query}"
HEADERS = {}
cookies = {}  # ضع كوكيز هنا إن أردت
MAX_PAGES = 10
SLEEP_BETWEEN = 0.6

# الخيارات الخاصة بالعناوين المفقودة
RESOLVE_MISSING_TITLES = True    # إذا True: سيجرب oEmbed لجلب العناوين المفقودة
MAX_OEMBED_LOOKUPS = 30          # حد عدد طلبات oEmbed ليمنع الكثير من الطلبات

session = requests.Session()
session.headers.update(HEADERS)

# ---------------- utilities لاستخراج العنوان ----------------
def _get_text_from_field(t):
    if not t:
        return None
    if isinstance(t, str):
        return t.strip() or None
    if isinstance(t, dict):
        # runs -> join text
        runs = t.get("runs")
        if isinstance(runs, list) and runs:
            return "".join([r.get("text","") for r in runs]).strip() or None
        if "simpleText" in t and isinstance(t["simpleText"], str):
            return t["simpleText"].strip() or None
        if "text" in t and isinstance(t["text"], str):
            return t["text"].strip() or None
        # accessibility label (some renderers)
        a = t.get("accessibility") or t.get("accessibilityData")
        if isinstance(a, dict):
            lbl = a.get("label") or a.get("accessibilityData", {}).get("label")
            if isinstance(lbl, str):
                return lbl.strip() or None
    return None

def extract_title_from_obj(obj) -> Optional[str]:
    """
    يحاول استخراج عنوان من كثير من الحقول المعروفة داخل obj.
    يرجع None إن لم يجد عنواناً واضحاً.
    """
    if not isinstance(obj, dict):
        return None

    # شوف الحقول الشائعة
    candidates = [
        obj.get("title"),
        obj.get("headline"),
        obj.get("primaryText"),
        obj.get("overlayMetadata", {}).get("primaryText"),
        obj.get("shortBylineText"),
        obj.get("longBylineText"),
        obj.get("byline"),
        obj.get("simpleText"),
        obj.get("text"),
        obj.get("name"),
        obj.get("metadata", {}).get("lockupMetadataViewModel", {}).get("title"),
        obj.get("accessibility", {}).get("label")
    ]

    for c in candidates:
        t = _get_text_from_field(c)
        if t:
            return t

    # تحقق داخل title nested structures (common)
    t1 = obj.get("title") or {}
    t = _get_text_from_field(t1)
    if t:
        return t

    # بعض البنى تضع title داخل nested keys
    for key in ("videoRenderer", "compactVideoRenderer", "gridVideoRenderer", "reelItemRenderer", "lockupViewModel"):
        sub = obj.get(key)
        if isinstance(sub, dict):
            t = extract_title_from_obj(sub)
            if t:
                return t

    return None

# ---------------- جمع الفيديوهات من renderers الشائعة ----------------
def collect_from_renderer(obj, out_list: List[Dict[str,str]], seen_ids: set):
    if not isinstance(obj, dict):
        return

    # videoRenderer
    if "videoRenderer" in obj:
        v = obj["videoRenderer"]
        vid = v.get("videoId")
        title = extract_title_from_obj(v)
        if vid and vid not in seen_ids:
            seen_ids.add(vid)
            out_list.append({"id": vid, "title": title or "", "link": f"https://www.youtube.com/watch?v={vid}"})
        return

    # compactVideoRenderer
    if "compactVideoRenderer" in obj:
        v = obj["compactVideoRenderer"]
        vid = v.get("videoId")
        title = extract_title_from_obj(v)
        if vid and vid not in seen_ids:
            seen_ids.add(vid)
            out_list.append({"id": vid, "title": title or "", "link": f"https://www.youtube.com/watch?v={vid}"})
        return

    # gridVideoRenderer
    if "gridVideoRenderer" in obj:
        v = obj["gridVideoRenderer"]
        vid = v.get("videoId")
        title = extract_title_from_obj(v)
        if vid and vid not in seen_ids:
            seen_ids.add(vid)
            out_list.append({"id": vid, "title": title or "", "link": f"https://www.youtube.com/watch?v={vid}"})
        return

    # reelItemRenderer / shorts
    if "reelItemRenderer" in obj or "shorts" in json.dumps(obj).lower():
        vid = obj.get("videoId") or obj.get("reelItemRenderer", {}).get("videoId")
        title = extract_title_from_obj(obj)
        if vid and vid not in seen_ids:
            seen_ids.add(vid)
            t = title or ""
            if t and not t.lower().startswith("[shorts]"):
                t = "[Shorts] " + t
            elif not t:
                t = ""
            out_list.append({"id": vid, "title": t, "link": f"https://www.youtube.com/shorts/{vid}"})
        return

    # otherwise dive deeper
    for v in obj.values():
        if isinstance(v, dict):
            collect_from_renderer(v, out_list, seen_ids)
        elif isinstance(v, list):
            for it in v:
                if isinstance(it, dict):
                    collect_from_renderer(it, out_list, seen_ids)

# ---------------- deep scan refined ----------------
def deep_scan_for_videos(obj, out_list: List[Dict[str,str]], seen_ids: set):
    if isinstance(obj, dict):
        # direct videoId
        vid = obj.get("videoId") or obj.get("id") or obj.get("video_id")
        if vid and str(vid) not in seen_ids:
            title = extract_title_from_obj(obj)
            # لا تضيف إن لم نجد عنوان — خزّن فقط للإمكان محاولة oEmbed لاحقًا
            seen_ids.add(str(vid))
            out_list.append({"id": str(vid), "title": title or "", "link": f"https://www.youtube.com/watch?v={vid}"})
        # dive deeper
        for v in obj.values():
            deep_scan_for_videos(v, out_list, seen_ids)
    elif isinstance(obj, list):
        for it in obj:
            deep_scan_for_videos(it, out_list, seen_ids)

# ---------------- oEmbed لجلب العناوين المفقودة ----------------
def fetch_title_oembed(video_id: str) -> Optional[str]:
    # يستخدم oEmbed الرسمي: https://www.youtube.com/oembed?url=...&format=json
    try:
        ourl = f"https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v={video_id}&format=json"
        r = session.get(ourl, timeout=10)
        if r.status_code == 200:
            j = r.json()
            return j.get("title")
    except Exception:
        pass
    return None

# ---------------- استخراج ytInitialData و innertube config ----------------
def extract_ytInitialData(html_text: str):
    m = re.search(r"var ytInitialData\s*=\s*({.*?});", html_text, flags=re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    m2 = re.search(r"window\[['\"]ytInitialData['\"]\]\s*=\s*({.*?});", html_text, flags=re.DOTALL)
    if m2:
        try:
            return json.loads(m2.group(1))
        except Exception:
            pass
    return None

def find_innertube_cfg(html_text: str):
    cfg = {}
    m = re.search(r"ytcfg\.set\(\s*(\{.*?\})\s*\);", html_text, flags=re.DOTALL)
    if m:
        try:
            cfg = json.loads(m.group(1))
            return cfg
        except Exception:
            pass
    # fallback: search keys
    for key in ("INNERTUBE_API_KEY", "INNERTUBE_CLIENT_VERSION", "VISITOR_DATA"):
        mm = re.search(rf'"{key}"\s*:\s*"([^"]+)"', html_text)
        if mm:
            cfg[key] = mm.group(1)
    return cfg

# ---------------- extract items from continuation (re-use improved collect) ----------------
def extract_items_from_cont_response_with_fallback(j):
    items = []
    seen_local = set()

    # sectionListContinuation
    try:
        sec = j.get("continuationContents", {}).get("sectionListContinuation", {}).get("contents")
        if sec:
            for block in sec:
                if isinstance(block, dict) and 'itemSectionRenderer' in block:
                    for c in block['itemSectionRenderer'].get('contents', []):
                        collect_from_renderer(c, items, seen_local)
                else:
                    collect_from_renderer(block, items, seen_local)
            if items:
                return items
    except Exception:
        pass

    # appendContinuationItemsAction
    try:
        for a in j.get("onResponseReceivedActions", []) + j.get("onResponseReceivedEndpoints", []) + j.get("onResponseReceivedCommands", []):
            if isinstance(a, dict) and "appendContinuationItemsAction" in a:
                cont_items = a["appendContinuationItemsAction"].get("continuationItems", [])
                for it in cont_items:
                    collect_from_renderer(it, items, seen_local)
                if items:
                    return items
    except Exception:
        pass

    # richGridContinuation
    try:
        grid = j.get("continuationContents", {}).get("richGridContinuation", {}).get("items", [])
        if grid:
            for it in grid:
                collect_from_renderer(it, items, seen_local)
            if items:
                return items
    except Exception:
        pass

    # final fallback: deep scan (but collect titles too if present)
    try:
        deep_scan_for_videos(j, items, seen_local)
        if items:
            return items
    except Exception:
        pass

    return items

def find_next_continuation_token_flexible(j):
    try:
        for a in j.get("onResponseReceivedActions", []) + j.get("onResponseReceivedCommands", []) + j.get("onResponseReceivedEndpoints", []):
            if isinstance(a, dict) and "appendContinuationItemsAction" in a:
                arr = a["appendContinuationItemsAction"].get("continuationItems", [])
                for it in arr[::-1]:
                    if isinstance(it, dict) and 'continuationItemRenderer' in it:
                        return it['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token']
    except Exception:
        pass
    try:
        conts = j.get("continuationContents", {}).get("sectionListContinuation", {}).get("continuations", [])
        for c in conts[::-1]:
            token = c.get("nextContinuationData", {}).get("continuation")
            if token:
                return token
    except Exception:
        pass
    try:
        items = j.get("continuationContents", {}).get("richGridContinuation", {}).get("items", [])
        for it in items[::-1]:
            if isinstance(it, dict) and 'continuationItemRenderer' in it:
                return it['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token']
    except Exception:
        pass
    try:
        js = json.dumps(j)
        m = re.search(r'"continuation"\s*:\s*"([^"]+)"', js)
        if m:
            return m.group(1)
    except Exception:
        pass
    return None

# ---------------- API continuation fetchers (مثل السابق) ----------------
def fetch_search_continuation(api_key, token, client_version, visitor_data):
    url_api = f"https://m.youtube.com/youtubei/v1/search?key={api_key}"
    payload = {"context": {"client": {"hl":"ar","gl":"IQ","clientName":"MWEB","clientVersion":client_version or "2.20251114.01.00","visitorData":visitor_data or "","platform":"MOBILE"}},"continuation":token}
    headers = {"Content-Type":"application/json","User-Agent":session.headers.get("User-Agent"),"X-Youtube-Client-Name":"MWEB","X-Youtube-Client-Version":client_version or "2.20251114.01.00"}
    if visitor_data:
        headers["X-Goog-Visitor-Id"] = visitor_data
    r = session.post(url_api, json=payload, headers=headers, cookies=cookies, timeout=25)
    r.raise_for_status()
    return r.json()

def fetch_browse_continuation(api_key, token, client_version, visitor_data):
    url_api = (f"https://m.youtube.com/youtubei/v1/browse" + (f"?key={api_key}" if api_key else ""))
    payload = {"context":{"client":{"clientName":"MWEB","clientVersion":client_version or "2.20251114.01.00","visitorData":visitor_data or ""}},"continuation":token}
    headers = {"Content-Type":"application/json","User-Agent":session.headers.get("User-Agent"),"X-Youtube-Client-Name":"MWEB","X-Youtube-Client-Version":client_version or "2.20251114.01.00"}
    if visitor_data:
        headers["X-Goog-Visitor-Id"] = visitor_data
    r = session.post(url_api, json=payload, headers=headers, cookies=cookies, timeout=25)
    r.raise_for_status()
    return r.json()

# ---------------- main flow ----------------
def main():
    print("جاري جلب الصفحة الأولى...")
    try:
        r = session.get(url, headers=HEADERS, cookies=cookies, timeout=25)
        r.raise_for_status()
        html = r.text
    except Exception as e:
        print("فشل جلب الصفحة الأولى:", e)
        return

    initial_data = extract_ytInitialData(html)
    if not initial_data:
        print("لم أجد ytInitialData في HTML.")
        return

    first_videos = []
    seen = set()
    try:
        # محاولة المسار الشائع
        try:
            contents = initial_data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
            for block in contents:
                if isinstance(block, dict) and 'itemSectionRenderer' in block:
                    for c in block['itemSectionRenderer'].get('contents', []):
                        collect_from_renderer(c, first_videos, seen)
                else:
                    collect_from_renderer(block, first_videos, seen)
        except Exception:
            deep_scan_for_videos(initial_data, first_videos, seen)
    except Exception as e:
        print("خطأ عند استخراج فيديوهات الصفحة الأولى:", e)

    # طباعة الدفعة الأولى
    print(f"\n--- الدفعة الأولى: تم العثور على {len(first_videos)} فيديو(هات) ---\n")
    for i, v in enumerate(first_videos, 1):
        title = v.get("title") or "(no title)"
        print(f"{i}. العنوان: {title}\n   الرابط: {v.get('link')}\n")

    # إعداد continuation keys
    cfg = find_innertube_cfg(html)
    api_key = cfg.get("INNERTUBE_API_KEY") if cfg else None
    client_version = cfg.get("INNERTUBE_CLIENT_VERSION") if cfg else None
    visitor_data = cfg.get("VISITOR_DATA") if cfg else None

    if api_key:
        print("تم العثور على INNERTUBE_API_KEY.")
    else:
        print("لم أجد INNERTUBE_API_KEY (سنحاول بدون مفتاح).")

    # استخراج continuation token
    continuation = None
    try:
        js_text = json.dumps(initial_data)
        m = re.search(r'"continuation"\s*:\s*"([^"]+)"', js_text)
        if m:
            continuation = m.group(1)
        else:
            # search structural
            try:
                sec = initial_data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
                for block in sec:
                    if isinstance(block, dict) and 'continuationItemRenderer' in block:
                        continuation = block['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token']
                        break
                    if 'itemSectionRenderer' in block:
                        for c in block['itemSectionRenderer'].get('contents', []):
                            if isinstance(c, dict) and 'continuationItemRenderer' in c:
                                continuation = c['continuationItemRenderer']['continuationEndpoint']['continuationCommand']['token']
                                break
                        if continuation:
                            break
            except Exception:
                pass
    except Exception:
        continuation = None

    if not continuation:
        print("لم أجد continuation — لا صفحات إضافية.")
        return

    # all_videos initialization (dedupe global)
    all_videos = first_videos[:]
    seen_global = {v.get("id") for v in all_videos if v.get("id")}

    print("\nبدأ جلب الصفحات التالية (continuation)...")
    page = 0
    while continuation and (MAX_PAGES is None or page < MAX_PAGES):
        page += 1
        print(f"\nجلب صفحة continuation رقم {page} ...")
        j = None
        try:
            if api_key:
                try:
                    j = fetch_search_continuation(api_key, continuation, client_version, visitor_data)
                except Exception:
                    j = fetch_browse_continuation(api_key, continuation, client_version, visitor_data)
            else:
                j = fetch_browse_continuation("", continuation, client_version, visitor_data)
        except Exception as e:
            print("فشل طلب continuation:", e)
            break

        if not j:
            print("رد السيرفر فارغ.")
            break

        items = extract_items_from_cont_response_with_fallback(j)
        if not items:
            print("لم أعثر على عناصر لهذه الصفحة (حتى بعد fallback).")
            # طباعة مقتطف لتصحيح الحالة إن أردت
            try:
                print("مفاتيح الرد:", list(j.keys())[:12])
                print("مقتطف:", json.dumps(j, ensure_ascii=False)[:800])
            except Exception:
                pass
            break

        added = 0
        for it in items:
            vid = it.get("id")
            if not vid and it.get("link") and "/watch?v=" in it.get("link"):
                vid = it.get("link").split("/watch?v=")[-1].split("&")[0]
            if vid and vid not in seen_global:
                seen_global.add(vid)
                all_videos.append({"id": vid, "title": it.get("title") or "", "link": it.get("link") or f"https://www.youtube.com/watch?v={vid}"})
                added += 1

        next_token = find_next_continuation_token_flexible(j)
        if not next_token:
            print("انتهت صفحات continuation.")
            break
        continuation = next_token
        print(f"الصفحة {page}: تمت إضافة تقريباً {added} عناصر. المجموع الآن: {len(all_videos)}")
        time.sleep(SLEEP_BETWEEN)

    # --------- محاولة حل العناوين المفقودة عبر oEmbed (اختياري) ----------
    if RESOLVE_MISSING_TITLES:
        missing = [v for v in all_videos if not v.get("title")]
        if missing:
            print(f"\nمحاولة جلب العناوين المفقودة عبر oEmbed (الحد: {MAX_OEMBED_LOOKUPS}) — عناصر بدون عنوان: {len(missing)}")
            lookups = 0
            for v in missing:
                if lookups >= MAX_OEMBED_LOOKUPS:
                    break
                vid = v["id"]
                title = fetch_title_oembed(vid)
                if title:
                    v["title"] = title
                else:
                    # احتياطي: ضع علامة واضحة بدلاً من المعرف وحده
                    v["title"] = f"(no title) {vid}"
                lookups += 1
                time.sleep(0.25)

    # ----- طباعة النتيجة المجمعة -----
    print("\n---- النتائج المجمعة ----\n")
    for i, v in enumerate(all_videos, 1):
        print(f"{i}. العنوان: {v.get('title')}\n   الرابط: {v.get('link')}\n")
    print("انتهى.")

if __name__ == "__main__":
    main()